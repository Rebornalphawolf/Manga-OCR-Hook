# MangaOCR Hook (ShareX → MangaOCR → OCR Hook)

This is a **portable** folder you can zip and share. It avoids hardcoding your personal Python install path.

## What this does
- Runs a **persistent MangaOCR server** on `127.0.0.1:8766` (loads the model once, fast OCR after that).
- ShareX calls a tiny client script with `%input` and writes output to `result.txt`.
- A local hook page (served on `127.0.0.1:8765`) shows the latest OCR text for easy copy/paste.

## Requirements (user installs these)
1) Python 3.11 (64-bit) 
-download from "https://www.python.org/downloads/" and be sure to click "Add python.exe to PATH" when downloading

2) ShareX from "https://getsharex.com/"

## 1) Install (one time)
1. Unzip this folder to **C:\ocr** (recommended).
2. Double-click `Install.bat` (creates `C:\ocr\venv` and installs `manga-ocr`).

## 2) Start servers (EVERY time you restart PC you must do this)
- Double-click `Start.bat`
- Open the hook page: http://127.0.0.1:8765

## 3) ShareX custom action
Step 1) Open ShareX
Step 2) Click the After capture tasks and ensure only "Save image to file" and "Perform actions" are checked
Step 3) Click Task Settings -> Click Actions -> Click Add  -> Name it MangaOCR Hook
Step 4) Paste "C:\ocr\venv\Scripts\pythonw.exe" into File path:
Step 5) Paste ""C:\ocr\mocr_client_to_txt.py" "%input"" into Arguments
Step 6) Ensure Hidden window is checked
Step 6) Click the checkbox next to the MangaOCR Hook action below the stock "Paint" action
Step 7) click OK and close Actions window
Step 8) Click Hotkey settings -> Next to Capture region click and change to Ctrl + Shift + F
Step 9) Close Hotkey settings page and minimize ShareX -> DONE

## Notes
- First ever startup is slow because the model is downloading/loading.