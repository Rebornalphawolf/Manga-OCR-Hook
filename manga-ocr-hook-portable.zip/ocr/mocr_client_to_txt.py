# mocr_client_to_txt.py
# Called by ShareX with "%input" (image file path).
# Writes OCR output to result.txt for easy integration.

import os, sys, json
from pathlib import Path
from urllib.parse import quote
from urllib.request import urlopen

# Silence console when launched via pythonw
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

BASE_DIR = Path(__file__).resolve().parent
OUT = BASE_DIR / "result.txt"
SERVER = "http://127.0.0.1:8766/ocr?img="

def main():
    # If ShareX calls us without an argument, clear output.
    if len(sys.argv) < 2:
        OUT.write_text("", encoding="utf-8")
        return

    img = sys.argv[1].strip().strip('"')
    if not Path(img).exists():
        OUT.write_text("", encoding="utf-8")
        return

    try:
        with urlopen(SERVER + quote(img), timeout=20) as r:
            data = json.loads(r.read().decode("utf-8", errors="ignore"))
        OUT.write_text(data.get("text", ""), encoding="utf-8")
    except Exception as e:
        OUT.write_text(f"[client] {e}", encoding="utf-8")

if __name__ == "__main__":
    main()
