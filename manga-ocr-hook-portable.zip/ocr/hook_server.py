# hook_server.py
# Local web UI for viewing latest OCR output (polls result.txt).
import os, sys, time, socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

HOST = "127.0.0.1"
PORT = 8765

# Silence console when launched via pythonw
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

BASE_DIR = Path(__file__).resolve().parent
RESULT = BASE_DIR / "result.txt"
INDEX = BASE_DIR / "hook" / "index.html"

def port_in_use(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex((host, port)) == 0

if port_in_use(HOST, PORT):
    raise SystemExit(f"Hook server already running on {HOST}:{PORT}")

class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def _send(self, body: bytes, code=200, ctype="text/plain; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)

        if u.path in ("/", "/index.html"):
            if INDEX.exists():
                return self._send(INDEX.read_bytes(), 200, "text/html; charset=utf-8")
            return self._send(b"Missing hook/index.html", 500)

        if u.path == "/text":
            try:
                txt = RESULT.read_text(encoding="utf-8") if RESULT.exists() else ""
            except Exception:
                txt = ""
            return self._send(txt.encode("utf-8"), 200, "text/plain; charset=utf-8")

        return self._send(b"not found", 404)

def main():
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()

if __name__ == "__main__":
    main()
