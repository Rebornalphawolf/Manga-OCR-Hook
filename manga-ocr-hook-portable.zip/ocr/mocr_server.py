# mocr_server.py
# Persistent MangaOCR HTTP server (loads model once).
import os, sys, json, socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

HOST = "127.0.0.1"
PORT = 8766

# Silence console windows/log spam when launched via pythonw
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

def port_in_use(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex((host, port)) == 0

if port_in_use(HOST, PORT):
    raise SystemExit(f"Server already running on {HOST}:{PORT}")

from manga_ocr import MangaOcr  # noqa: E402
MOCR = MangaOcr()  # load once (this is the expensive part)

class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def _send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/health":
            return self._send_json({"ok": True})
        if u.path != "/ocr":
            return self._send_json({"error": "not found"}, 404)

        img = parse_qs(u.query).get("img", [""])[0]
        if not img:
            return self._send_json({"error": "missing img"}, 400)

        p = Path(img)
        if not p.exists():
            return self._send_json({"error": f"file not found: {img}"}, 400)

        try:
            return self._send_json({"text": (MOCR(str(p)) or "").strip()})
        except Exception as e:
            return self._send_json({"error": str(e)}, 500)

def main():
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()

if __name__ == "__main__":
    main()
